#include<stdio.h>
int lightDark(int x){	
	if(x>=200)
	return 0;
	else if(x<=100)
	return 1;
	else return -1;
	
}
main(){
	int m,n,i,j;
	printf("\t\t\t\t\tQuestion-2\n");	
	printf("Enter Dimensions of Image Matrix e.g 9*9 pixels: ");
	scanf("%d%*c%d",&m,&n);
	int img[m][n];
	srand(time(0));
	for(i=1;i<=m;i++){
		for(j=1;j<=n;j++){
		img[i][j]=rand()%256;
		}
	}
	for(i=1;i<=m;i++){
		for(j=1;j<=n;j++){
		printf("%d\t",img[i][j]);
		}
	printf("\n\n");		
	}
	printf("\n\t\t\t\t\tQuestion-3\n");
	int d=0,l=0,x;
	for(i=1;i<=m;i++){
		for(j=1;j<=n;j++){
		x=lightDark(img[i][j]);
		if(x==1)
		d++;
		if(x==0)
		l++;
		}	
	}
	if(d>l)
	printf("\nImage is Dark");
	else if (l>d)
	printf("\nImage is Light");
	else
	printf("\nImage is neither Light nor Dark");
	
}

