#include <stdio.h>
#include <stdlib.h>
int main(){
	int r1,c1,r2,c2,i,j;
	printf("Enter dimentions of matrix X (e.g 3x3): ");
	scanf("%d%*c%d",&r1,&c1);
	int x[r1][c1];
	printf("Enter dimentions of matrix Y (e.g 3x3): ");
	scanf("%d%*c%d",&r2,&c2);
	int y[r2][c2];
	
	if (r1!=r2 || c2!=c2){
		printf("Cant add this matrix!");
		exit(1);
	}
	
	printf("Enter values of matrix X: \n");
	for(i=1;i<=r1;i++){
		
		for(j=1;j<=c1;j++){
			printf("%d %d: ",i,j);
			scanf(" %d",&x[i][j]);
		}
		printf("\n");
	}
	printf("Enter values of matrix y: \n");
	for(i=1;i<=r2;i++){
		for(j=1;j<=c2;j++){
			printf("%d %d: ",i,j);
			scanf(" %d",&y[i][j]);
		}
		printf("\n");
	}
	printf("Addition of matrix X & Y is: \n");
	for(i=1;i<=r2;i++){
		for(j=1;j<=c2;j++){
			printf("%d \t",x[i][j]+y[i][j]);
		}
		printf("\n");
	}
}
