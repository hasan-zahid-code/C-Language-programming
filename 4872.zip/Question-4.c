#include <stdio.h>
#include <stdlib.h>
int main(){
	int r1,c1,r2,c2,i,j;
	printf("Enter dimensions of matrix X (e.g 3x3): ");
	scanf("%d%*c%d",&r1,&c1);
	int x[r1][c1];
	printf("Enter dimensions of matrix Y (e.g 3x3): ");
	scanf("%d%*c%d",&r2,&c2);
	int y[r2][c2];
	
	if (r2!=c1){
		printf("Cant Multiply this matrix!");
		exit(1);
	}
	
	printf("Enter values of matrix X: \n");
	for(i=1;i<=r1;i++){
		
		for(j=1;j<=c1;j++){
			printf("%d %d: ",i,j);
			scanf(" %d",&x[i][j]);
		}
		printf("\n");
	}
	printf("Enter values of matrix y: \n");
	for(i=1;i<=r2;i++){
		for(j=1;j<=c2;j++){
			printf("%d %d: ",i,j);
			scanf(" %d",&y[i][j]);
		}
		printf("\n");
	}
	
	//resultant matrix
	int z[r1][c2],k,temp=0;
	//init z
	for(i=1;i<=r1;i++){
		for(j=1;j<=c2;j++)	z[i][j]=0;
	}
	//multiplication
	for (i=1;i<=r1;++i) {
      for (j=1;j<=c2;++j) {
         for (k=1;k<=c1;++k) {
				z[i][j]+=x[i][k]*y[k][j];
			}
		}
	}

	printf("Resultant Matrix: \n");
	for(i=1;i<=r1;i++){
		for(j=1;j<=c2;j++){
			printf("%d ",z[i][j]);
		}
		printf("\n");
	}
	
}
