#include <stdio.h>
#include <math.h>
#include <stdlib.h>
float sigmoid(float z){
	float r, e=2.718;
	r=1/(1+pow(e,-z));
	return r;
}
int max(int d, int z){
	if (z<0)	return d; else return z;
}

int main(){
	int f,r=3,c=3,i,j;
	
	printf("Which activation function do you wanna run? \n 1-ReLU \n 2-Sigmoid?\t ");
	scanf("%d",&f);
	if (f==1){
		int x[r][c];
		printf("Enter values of matrix: \n");
		for(i=1;i<=r;i++){
			for(j=1;j<=c;j++){
				printf("%d %d: ",i,j);
				scanf(" %d",&x[i][j]);
				x[i][j]=max(0,x[i][j]);
		}
		printf("\n");
		}
		//printing the matrix
		printf("ReLU Operation: \n");
		for(i=1;i<=r;i++){
			for(j=1;j<=c;j++){
				printf("%d \t",x[i][j]);
			}
			printf("\n");
		}
		}

	else if (f==2){
		float x[r][c];
		printf("Enter values of matrix: \n");
		for(i=1;i<=r;i++){
			for(j=1;j<=c;j++){
				printf("%d %d: ",i,j);
				scanf(" %f",&x[i][j]);
				x[i][j]=sigmoid(x[i][j]);
		}
		printf("\n");
		}
		//printing the matrix
		printf("Sigmoid Operation: \n");
		for(i=1;i<=r;i++){
			for(j=1;j<=c;j++){
				printf("%.2f \t",x[i][j]);
			}
			printf("\n");
		}
	}
	else {	printf("Invalid Choice. Program Treminated!");	exit(1);	}
	
	
}

