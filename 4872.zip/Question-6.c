#include <stdio.h>
#include <stdlib.h>
get_image(int x[5][5]){
	int i,j;
	srand(time(0));
	for(i=0;i<5;i++){
		for(j=0;j<5;j++){
			x[i][j]=rand()%2;
		}
	}
}
int get_kernel(int x[3][3]){
	int i,j;
	// 3x3 Kernel input
	printf("Enter values of Kernel 3x3 matrix: \n");
	for(i=0;i<3;i++){
		for(j=0;j<3;j++){
			printf("%d%d: ",i+1,j+1);
			scanf(" %d",&x[i][j]);
		}
		printf("\n");
	}
	
}
int convolution(int kernel[3][3],int img[5][5],int res[3][3]){
	int i,j,k,l,r=0,c=0;
	for (k=0;k<3;++k) {
	    for (l=0;l<3;++l) {
			//multiplication
			for (i=0;i<3+k;++i) {
		      for (j=0;j<3+l;++j) {
		      	res[k][l]+=kernel[i][j]*img[i+k][j+l];
				}
			}
		}
	}
}
int print_matrix(int x[5][5],int r,int c){
	int i,j;
	printf("Values: \n");
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
			printf("%d%d: %d\t",i+1,j+1,x[i][j]);
		}
		printf("\n");
	}
	
}
int main(){
	int r,c,kernel[3][3],output[3][3],image[5][5];
	// Init output matrix
	int i,j;
	for(i=0;i<3;i++){
		for(j=0;j<5;j++){
			output[i][j]=0;
		}
	}
	//Generating image values randomly
	get_image(image);
	printf("Image Matrix \n");
	print_matrix(image,5,5);
	
	//Input kernel values 
	get_kernel(kernel);
	//Apply convolution
	convolution(kernel,image,output);
	//Print Output Matrix
	printf("Output Matrix \n");
	print_matrix(output,3,3);
}
	
