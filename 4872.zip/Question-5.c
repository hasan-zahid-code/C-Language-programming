#include <stdio.h>
#include <stdlib.h>
int main(){
	int r,c,i,j;
	printf("Enter dimensions of matrix X: ");
	scanf("%d%*c%d",&r,&c);
	int x[r][c];
		
	printf("Enter values of matrix: \n");
	for(i=1;i<=r;i++){
		for(j=1;j<=c;j++){
			printf("%d%d: ",i,j);
			scanf(" %d",&x[i][j]);
		}
		printf("\n");
	}
	
	printf("Transpose of matrix: \n");
	for(i=1;i<=c;i++){
		for(j=1;j<=r;j++){
			printf("%d%d: %d\t",i,j,x[j][i]);
		}
		printf("\n");
	}
	//for identity Matrix
	if(r==c){
	int count1=0,count0=0;
	for(i=1;i<=r;i++){
		for(j=1;j<=c;j++){
			if (r==c && x[i][j]==1)count1++;
			else if (x[i][j]==0)count0++;
			else break;
		}
	}
	if(count1==r && count0==(r*c-r))
	printf("\nIts an identity Matrix!");
	else
	printf("\nIts not an identity Matrix!");
	}
	else
	printf("\nThis cant be identity Matrix!");
}
